package takingDiffrentInputs;

import java.util.Scanner;

public class IntDemo {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter int  value");

		int a = sc.nextInt();

		System.out.println("int value is:" + a);
	}
}
