package takingDiffrentInputs;

import java.util.Scanner;

public class LongDemo {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter long value");
		long l=sc.nextLong();
		
		System.out.println("the value is:"+l);
	}
}
