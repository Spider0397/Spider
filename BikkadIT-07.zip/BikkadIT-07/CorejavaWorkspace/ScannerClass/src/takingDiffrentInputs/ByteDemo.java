package takingDiffrentInputs;

import java.util.Scanner;

public class ByteDemo {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter byte value");
		byte b = sc.nextByte();

		System.out.println("value is :" + b);

	}
}
