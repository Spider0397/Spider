package takingDiffrentInputs;

import java.util.Scanner;

public class BooleanDemo {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter any boolean value");
		boolean b=sc.nextBoolean();
		System.out.println("Boolean value is:"+b);
	}
}
