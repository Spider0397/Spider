package takingDiffrentInputs;

import java.util.Scanner;

public class DoubleDemo {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter double value");

		double d = sc.nextDouble();
		
		System.out.println("Double value is:"+d);
	}
}
