package takingDiffrentInputs;

import java.util.Scanner;

public class FloatDemo {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter float value");
		
		float no = sc.nextFloat();
		
		System.out.println("float value is:"+ no);
		
	}
}
