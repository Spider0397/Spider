package basicsOfArray;

public class Demo {

	public static void main(String[] args) {

		String a[] = new String[5];
		a[0] = "Santosh";
		a[1] = "Bikkad";
		a[2] = "IT";
		a[3] = "Pune";
		a[4] = "Java";

	for(String a1:a) {
		System.out.println(a1);
	}
		
	}
}
