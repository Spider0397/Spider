package loopingStatement;

public class Demo {

	public static void main(String[] args) {
		
		System.out.println("Welocme To BikkadIT");
		System.out.println("Welocme To BikkadIT");
		System.out.println("Welocme To BikkadIT");
		System.out.println("Welocme To BikkadIT");
		System.out.println("Welocme To BikkadIT");
		
		System.out.println("Welocme To BikkadIT");
		System.out.println("Welocme To BikkadIT");
		System.out.println("Welocme To BikkadIT");
		System.out.println("Welocme To BikkadIT");
		System.out.println("Welocme To BikkadIT");
	
		
}
}