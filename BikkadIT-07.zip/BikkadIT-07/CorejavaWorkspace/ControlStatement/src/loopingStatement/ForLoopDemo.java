package loopingStatement;

public class ForLoopDemo {

	public static void main(String[] args) {
		
	
		for(int i=10;i>=1;--i) {
			System.out.println(i);
	
		}
		
	}
}
