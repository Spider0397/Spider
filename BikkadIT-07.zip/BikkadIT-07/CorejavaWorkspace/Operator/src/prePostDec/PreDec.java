package prePostDec;

public class PreDec {

	public static void main(String[] args) {

		int a = 10;
		System.out.println(--a);
	}
}
