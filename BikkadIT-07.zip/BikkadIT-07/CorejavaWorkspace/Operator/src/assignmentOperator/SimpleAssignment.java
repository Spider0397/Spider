package assignmentOperator;

public class SimpleAssignment {

	public static void main(String[] args) {

		int a = 23;
		System.out.println(a);
	}
}