package prePostIncOperator;

public class PreIncOperator {

	public static void main(String[] args) {
		
		int a=10;
		System.out.println(++a);
		
	}
}
