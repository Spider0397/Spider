package typesOfOperator;

public class ArithmeticOperator {

	
	public static void main(String[] args) {
		
		System.out.println("+ operator");
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println("Addition of a and b is :"+c);
		
		System.out.println("- operator");
		
		int p=20;
		int q=10;
		int r=p-q;
		System.out.println("Sub of p and q is:"+r);
		
		System.out.println("* operator");
		
		int x=10;
		int y=2;
		int z=x*y;
		System.out.println("Mul of x And y is:"+ z);
		
		System.out.println("/ operator");
		int e=21;
		int f=2;
		int g=e/f;
		System.out.println("div of e and f is:"+g);
		
		System.out.println("% operator");
		
		int s=27;
		int t=7;
		int u=s % t;
		System.out.println("mod of s and t is:"+u);
		
		
	}
}
