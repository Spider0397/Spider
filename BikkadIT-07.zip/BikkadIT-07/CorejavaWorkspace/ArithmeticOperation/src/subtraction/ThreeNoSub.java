package subtraction;

public class ThreeNoSub {

	public static void main(String args[]) {
		
		int r=60;
		int x=30;
		int y=10;
		int z=r-x-y;
		System.out.println(z);
	}
}
