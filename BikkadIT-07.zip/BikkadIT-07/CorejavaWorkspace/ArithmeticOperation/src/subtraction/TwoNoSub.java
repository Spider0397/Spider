package subtraction;

public class TwoNoSub {

	public static void main(String args[]) {
		
		int x=30;
		int y=20;
		int z=x-y;
		System.out.println(z);
	}
}
