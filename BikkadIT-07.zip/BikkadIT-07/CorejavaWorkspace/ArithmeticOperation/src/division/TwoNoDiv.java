package division;

public class TwoNoDiv {

	public static void main(String[] args) {
		
		int a=20;
		int b=2;
		int c=a/b;
		System.out.println(c);
	}
}
