package division;

public class ThreeNoDiv {

	public static void main(String[] args) {

		int a = 100;
		int b = 10;
		int c = 2;
		int d = a / b / c;
		System.out.println(d);
	}
}
