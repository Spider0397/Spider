package rules;

public class Rule5 {

	public static void main(String[] args) {
		
		int if=20;
		System.out.println(if);
		
		int double =23;
		
	}
}
