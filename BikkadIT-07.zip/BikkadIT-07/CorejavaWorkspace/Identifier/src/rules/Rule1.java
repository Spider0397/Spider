package rules;

public class Rule1 {

	public static void main(String[] args) {
		
		int AzZCca$_456=10;
		System.out.println(AzZCca$_456);
	}
}
