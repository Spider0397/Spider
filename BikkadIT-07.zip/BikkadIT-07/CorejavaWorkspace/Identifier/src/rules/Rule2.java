package rules;

public class Rule2 {

	public static void main(String[] args) {
		
	//	int 8a=20;
	//	System.out.println(a);
	}
}
