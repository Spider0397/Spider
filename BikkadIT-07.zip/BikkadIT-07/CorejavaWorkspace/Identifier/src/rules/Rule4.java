package rules;

public class Rule4 {

	public static void main(String[] args) {
		
		int aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa=10;
		System.out.println(aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa);
		
		int aaaaaaaaaaaaaaa=20;
		System.out.println(aaaaaaaaaaaaaaa);
		
	}
}
