package rules;

public class Rule6 {

	public static void main(String[] args) {
		
		int String=90;
		System.out.println(String);
		
	}
}
