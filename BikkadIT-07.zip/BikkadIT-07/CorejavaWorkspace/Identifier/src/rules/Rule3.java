package rules;

public class Rule3 {

	public static void main(String[] args) {

		int a=15;
		System.out.println(a);
		int A=20;
		System.out.println(A);
	}
}
