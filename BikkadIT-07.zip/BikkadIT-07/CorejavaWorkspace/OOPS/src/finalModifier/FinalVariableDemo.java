package finalModifier;

public class FinalVariableDemo {

	public static void main(String[] args) {

		final int a = 10;
		System.out.println(a);

		a = 20;
		System.out.println(a);

	}
}
