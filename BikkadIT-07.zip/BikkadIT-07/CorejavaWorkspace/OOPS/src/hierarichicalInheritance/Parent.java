package hierarichicalInheritance;

public class Parent {

	public void m1() {
		System.out.println("m1 method of Parent class");
	}
}
