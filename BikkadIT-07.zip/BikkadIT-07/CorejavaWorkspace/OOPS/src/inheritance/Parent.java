package inheritance;

public class Parent  {

	int p=500;
	
	int q=2000;
	
	public void add() {
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println(c);
	}
	
	public void mul() {
		int x=20;
		int y=10;
		int z=x *y;
		System.out.println(z);
	}
	
	
}
