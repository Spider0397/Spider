package multipleInheritance;

public class Parent1 {

	public void m1() {
		System.out.println("m1 method of Parent 1 class");
	}
	
	
}
