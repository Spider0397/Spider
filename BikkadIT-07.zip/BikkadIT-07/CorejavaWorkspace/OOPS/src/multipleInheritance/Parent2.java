package multipleInheritance;

public class Parent2 {

	public void m1() {
		System.out.println("m2 methid of Parent2 class");
	}
}
