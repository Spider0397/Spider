package multipleInheritance;

public class Child extends Parent1,Parent2
{

	public void m3() {
		System.out.println("m3 method of Child class");
	}

	public static void main(String[] args) {
	 Child c=new Child();
	 
	  
}
}
