package hybridInheritance;

public class Child1 extends Parent {

	public void m2() {
		System.out.println("m2 method of Child1");
	}
}
