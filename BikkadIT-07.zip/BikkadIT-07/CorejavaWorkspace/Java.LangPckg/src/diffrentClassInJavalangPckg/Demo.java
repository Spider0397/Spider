package diffrentClassInJavalangPckg;

import java.util.ArrayList;
import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		String s = new String();

		StringBuffer sb = new StringBuffer();

		StringBuilder sb1 = new StringBuilder();

		ArrayList al=new ArrayList();
	}
}
