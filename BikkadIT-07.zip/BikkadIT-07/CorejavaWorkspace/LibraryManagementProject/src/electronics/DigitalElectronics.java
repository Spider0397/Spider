package electronics;

public class DigitalElectronics {

	public static void main(String args[]) {
		System.out.println("Digital Electronic Book");
	}
}
