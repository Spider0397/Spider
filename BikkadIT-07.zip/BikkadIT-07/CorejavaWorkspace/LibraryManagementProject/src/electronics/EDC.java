package electronics;

public class EDC {

	public static void main(String args[]) {
		System.out.println("EDC Book");
	}
}
