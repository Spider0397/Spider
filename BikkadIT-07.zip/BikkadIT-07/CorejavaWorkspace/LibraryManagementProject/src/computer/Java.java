package computer;

public class Java {

	public static void main(String args[]) {
		System.out.println("java Book");
	}
}
