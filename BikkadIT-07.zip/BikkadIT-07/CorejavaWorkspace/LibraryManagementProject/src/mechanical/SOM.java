package mechanical;

public class SOM {

	public static void main(String[] args) {
		
		System.out.println("SOM Book");
	}
}
