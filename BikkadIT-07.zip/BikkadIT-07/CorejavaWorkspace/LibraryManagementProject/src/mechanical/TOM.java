package mechanical;

public class TOM {

	public static void main(String[] args) {
		
		System.out.println("TOM Book");
	}
}
