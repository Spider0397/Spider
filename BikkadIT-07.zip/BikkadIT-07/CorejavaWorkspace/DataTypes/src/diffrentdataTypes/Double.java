package diffrentdataTypes;

public class Double {

	public static void main(String[] args) {
		
		double d=1234.1111111111111111111d;
		System.out.println(d);
		
		
		
	}
}
