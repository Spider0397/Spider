package diffrentdataTypes;

public class ByteDemo {

	public static void main(String[] args) {
		
		//range  -128 to +127
		byte b= 127;
		System.out.println(b);
	}
}
