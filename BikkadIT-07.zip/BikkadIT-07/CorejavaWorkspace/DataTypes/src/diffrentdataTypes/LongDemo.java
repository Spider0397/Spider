package diffrentdataTypes;

public class LongDemo {

	public static void main(String[] args) {

		//range -9223372036854775808 to 9223372036854775807
		long l = -9223372036854775808l;
		System.out.println(l);
	}
}
