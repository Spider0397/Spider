package diffrentdataTypes;

public class FloatDemo {

	public static void main(String[] args) {

		float f = 12.1111111111111111111111f;
		System.out.println(f);
	}
}
