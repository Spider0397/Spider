package diffrentdataTypes;

public class DefaultValuesOfDataType {

	static byte b=23;
	static short s=5677;
	static int i=47586868;
	static long l=74767766677L;
	static float f=12.1111111111111f;
	static double d=2344.1111111111111111111111d;
	static char c='Z';
	static boolean b1=true;

	public static void main(String[] args) {

		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		System.out.println(f);
		System.out.println(d);
		System.out.println(c);
		System.out.println(b1);

	}
}
