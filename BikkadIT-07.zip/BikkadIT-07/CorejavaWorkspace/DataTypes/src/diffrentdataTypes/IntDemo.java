package diffrentdataTypes;

public class IntDemo {

	public static void main(String[] args) {
		
		// -2147483648 to 2147483647
		
		int i=2147483647;
		System.out.println(i);
		
	}
}
