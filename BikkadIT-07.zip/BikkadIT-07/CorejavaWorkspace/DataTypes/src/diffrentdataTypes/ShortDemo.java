package diffrentdataTypes;

public class ShortDemo {

	public static void main(String[] args) {
		// range -32768 to +32767
		short s=32767;
		System.out.println(s);
	}
}
