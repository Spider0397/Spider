package diffrentdataTypes;

public class BooleanDemo {

	public static void main(String[] args) {
		
		boolean b=true;
		System.out.println(b);
	}
}
