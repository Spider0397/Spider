package diffrentdataTypes;

public class CharDemo {

	public static void main(String[] args) {
		
		char c='A';
		System.out.println(c);
	}
}
