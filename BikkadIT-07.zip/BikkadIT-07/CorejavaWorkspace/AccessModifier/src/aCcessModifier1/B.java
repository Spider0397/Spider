package aCcessModifier1;

public class B {

	public static void main(String[] args) {
		   
		 A a =new A();
		 System.out.println(a.i);
		 a.m1();
		
	}
}
