package aCcessModifier1;

class A {

  protected int i = 10;

	protected  void m1() {
		System.out.println("m1 method");
	}

}
