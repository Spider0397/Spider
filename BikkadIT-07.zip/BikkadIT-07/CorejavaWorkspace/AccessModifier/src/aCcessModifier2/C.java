package aCcessModifier2;

import aCcessModifier1.A;

public class C  {

	public static void main(String[] args) {
		
		A a=new A();
		
	}
}
