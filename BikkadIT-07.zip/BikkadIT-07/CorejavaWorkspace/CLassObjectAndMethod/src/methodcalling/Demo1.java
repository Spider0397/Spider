package methodcalling;

public class Demo1 {

	public void m1() {
		System.out.println("m1 method");
	}
	

}
