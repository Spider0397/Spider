package constructor;

public class Test {

	public static void main(String[] args) {
		
		Student stu1=new Student();
	}
}
