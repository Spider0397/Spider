package method;

import java.util.Scanner;

public class MethodDemo {

	public static void add() {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter value of a");
		int a = sc.nextInt();

		System.out.println("Enter value of b");
		int b = sc.nextInt();

		int c = a + b;
		System.out.println("Addition of a and b =" + c);
	}

	public static void main(String[] args) {
System.out.println("Main Method started");
		
        MethodDemo.add();

		System.out.println("Welcome To Bikkad IT");
		System.out.println("Welcome To Bikkad IT");
		System.out.println("Welcome To Bikkad IT");
		System.out.println("Welcome To Bikkad IT");
		System.out.println("Welcome To Bikkad IT");

		  MethodDemo.add();


		System.out.println("Welcome To Bikkad IT");
		System.out.println("Welcome To Bikkad IT");
		System.out.println("Welcome To Bikkad IT");
		System.out.println("Welcome To Bikkad IT");
		System.out.println("Welcome To Bikkad IT");

		  MethodDemo.add();

		
		System.out.println("Main Method Ended");
	}

}
