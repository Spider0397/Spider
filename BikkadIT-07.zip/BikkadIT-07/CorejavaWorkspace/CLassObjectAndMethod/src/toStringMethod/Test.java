package toStringMethod;

public class Test {

	
	public static void main(String[] args) {

		Student stu = new Student(111,"Santosh","Pune");
		 System.out.println(stu);
		
		Student stu1 = new Student(222,"Ganesh","Beed");
	System.out.println(stu1);
		
		
	}

}
