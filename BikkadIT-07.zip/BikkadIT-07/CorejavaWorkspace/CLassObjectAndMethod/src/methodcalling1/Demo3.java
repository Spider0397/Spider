package methodcalling1;

public class Demo3 {

	public void m3() {
		System.out.println("m3 method");
	}
}
