package com.ShubhamIT.appusingweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppusingwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppusingwebApplication.class, args);
	}

}
