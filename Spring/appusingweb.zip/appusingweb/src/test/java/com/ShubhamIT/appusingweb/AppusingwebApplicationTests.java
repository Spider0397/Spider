package com.ShubhamIT.appusingweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppusingwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
